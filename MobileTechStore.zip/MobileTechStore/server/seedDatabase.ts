import { db } from './db';
import { categories, products, users } from '@shared/schema';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcrypt';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Path to data files
const categoriesPath = path.join(__dirname, 'data', 'categories.json');
const productsPath = path.join(__dirname, 'data', 'products.json');
const usersPath = path.join(__dirname, 'data', 'users.json');

// Function to hash a password
async function hashPassword(password: string): Promise<string> {
  const saltRounds = 10;
  return await bcrypt.hash(password, saltRounds);
}

// Main seed function
async function seed() {
  try {
    console.log('Starting database seeding...');

    // Clear existing data (be careful with this in production!)
    console.log('Clearing existing data...');
    await db.delete(products);
    await db.delete(categories);
    await db.delete(users);
    
    // Seed categories
    console.log('Seeding categories...');
    const categoriesData = JSON.parse(fs.readFileSync(categoriesPath, 'utf8'));
    const insertedCategories = await db.insert(categories).values(categoriesData).returning();
    console.log(`Inserted ${insertedCategories.length} categories.`);
    
    // Create a map of category slugs to IDs for product seeding
    const categoryMap = new Map();
    insertedCategories.forEach(cat => {
      categoryMap.set(cat.slug, cat.id);
    });
    
    // Seed products
    console.log('Seeding products...');
    const productsData = JSON.parse(fs.readFileSync(productsPath, 'utf8'));
    
    // Map the categoryId from our JSON (which might be a number) to the actual DB ID
    const productsWithCorrectCategoryIds = productsData.map((product: any) => {
      const category = insertedCategories.find(c => c.id === product.categoryId);
      if (!category) {
        console.warn(`Category ID ${product.categoryId} not found for product ${product.name}`);
        return null;
      }
      return {
        ...product,
        categoryId: category.id
      };
    }).filter(Boolean);
    
    const insertedProducts = await db.insert(products).values(productsWithCorrectCategoryIds).returning();
    console.log(`Inserted ${insertedProducts.length} products.`);
    
    // Seed users
    console.log('Seeding users...');
    const usersData = JSON.parse(fs.readFileSync(usersPath, 'utf8'));
    
    // Insert users (passwords are already hashed in the JSON)
    const insertedUsers = await db.insert(users).values(usersData).returning();
    console.log(`Inserted ${insertedUsers.length} users.`);
    
    console.log('Database seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding database:', error);
  } finally {
    // Close database connection
    process.exit(0);
  }
}

// Run the seed function
seed();