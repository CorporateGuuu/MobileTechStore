import { FaHeart, FaShoppingCart, FaSearch } from "react-icons/fa";

export default function MainHeader() {
  return (
    <header className="bg-white py-4 shadow-md">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="flex items-center mb-4 md:mb-0">
            <a href="#" className="mr-6">
              <div className="flex items-center">
                <span className="text-3xl font-bold text-darkGray">Midas</span>
                <span className="text-3xl font-bold text-gold ml-2">Technical Solutions</span>
              </div>
            </a>
          </div>
          
          <div className="w-full md:w-2/5 mb-4 md:mb-0">
            <div className="relative">
              <input 
                type="text" 
                placeholder="Search entire store here..." 
                className="w-full py-2 px-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-gold"
              />
              <button className="absolute right-0 top-0 h-full px-4 bg-darkGray hover:bg-black/80 transition-colors text-gold rounded-r-md">
                <FaSearch />
              </button>
            </div>
          </div>
          
          <div className="flex items-center space-x-6">
            <a href="#" className="flex items-center text-dark-gray hover:text-gold transition-colors">
              <span className="relative">
                <FaHeart className="text-2xl" />
                <span className="absolute -top-2 -right-2 bg-darkGray text-gold text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </span>
              <span className="ml-2 hidden lg:inline">Wishlist</span>
            </a>
            <a href="#" className="flex items-center text-dark-gray hover:text-gold transition-colors">
              <span className="relative">
                <FaShoppingCart className="text-2xl" />
                <span className="absolute -top-2 -right-2 bg-darkGray text-gold text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  0
                </span>
              </span>
              <span className="ml-2 hidden lg:inline">Cart</span>
            </a>
          </div>
        </div>
      </div>
    </header>
  );
}
