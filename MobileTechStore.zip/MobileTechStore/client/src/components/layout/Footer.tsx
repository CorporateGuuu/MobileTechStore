import { 
  FaFacebookF, FaTwitter, FaInstagram, FaYoutube, 
  FaMapMarkerAlt, FaPhoneAlt, FaEnvelope, FaClock 
} from "react-icons/fa";

export default function Footer() {
  return (
    <footer className="bg-darkGray text-gold pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">About Midas Technical Solutions</h3>
            <p className="text-sm text-gray-400 mb-4">
              Midas Technical Solutions is a leading supplier of mobile phone parts, repair tools, and accessories for repair shops and consumers.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                <FaFacebookF />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                <FaTwitter />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                <FaInstagram />
              </a>
              <a href="#" className="text-gray-400 hover:text-gold transition-colors">
                <FaYoutube />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Customer Service</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Contact Us</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">FAQ</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Shipping Policy</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Return Policy</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Track Order</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Information</h3>
            <ul className="space-y-2">
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">About Us</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Terms & Conditions</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Blog</a></li>
              <li><a href="#" className="text-sm text-gray-400 hover:text-gold transition-colors">Sitemap</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3">
              <li className="flex items-start">
                <FaMapMarkerAlt className="mt-1 mr-3 text-gray-400" />
                <span className="text-sm text-gray-400">123 Repair Street, Miami, FL 33101</span>
              </li>
              <li className="flex items-center">
                <FaPhoneAlt className="mr-3 text-gray-400" />
                <span className="text-sm text-gray-400">+1 (240)-351-0511</span>
              </li>
              <li className="flex items-center">
                <FaEnvelope className="mr-3 text-gray-400" />
                <span className="text-sm text-gray-400">sales@midastechsolutions.com</span>
              </li>
              <li className="flex items-center">
                <FaClock className="mr-3 text-gray-400" />
                <span className="text-sm text-gray-400">Mon-Fri: 9AM-10PM EST</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="pt-8 border-t border-gray-700">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-4 md:mb-0">
              <div className="flex items-center">
                <span className="text-2xl font-bold text-gray-100">Midas</span>
                <span className="text-2xl font-bold text-gold ml-2">Technical Solutions</span>
              </div>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-400 mr-4">We Accept</span>
              <div className="flex space-x-2">
                <div className="h-6 w-10 bg-blue-800 rounded"></div>  {/* Visa */}
                <div className="h-6 w-10 bg-red-500 rounded"></div>   {/* Mastercard */}
                <div className="h-6 w-10 bg-blue-500 rounded"></div>  {/* Amex */}
                <div className="h-6 w-10 bg-orange-500 rounded"></div> {/* Discover */}
                <div className="h-6 w-10 bg-blue-600 rounded"></div>  {/* PayPal */}
              </div>
            </div>
          </div>
          <div className="text-center mt-6">
            <p className="text-xs text-gray-400">&copy; {new Date().getFullYear()} Midas Technical Solutions. All Rights Reserved.</p>
          </div>
        </div>
      </div>
    </footer>
  );
}
