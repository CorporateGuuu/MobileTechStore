import { FaPhoneAlt } from "react-icons/fa";
import { FaRegEnvelope } from "react-icons/fa";

export default function TopHeader() {
  return (
    <div className="bg-darkGray text-gold py-2">
      <div className="container mx-auto px-4 flex flex-col md:flex-row justify-between items-center">
        <div className="flex items-center space-x-4 mb-2 md:mb-0">
          <div className="flex items-center">
            <FaPhoneAlt className="mr-2 text-sm" />
            <span className="text-sm">+1 (240)-351-0511</span>
          </div>
          <div className="hidden md:flex items-center">
            <FaRegEnvelope className="mr-2 text-sm" />
            <span className="text-sm">sales@midastechsolutions.com</span>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <a href="#" className="text-sm hover:text-white transition-colors">My Account</a>
          <a href="#" className="text-sm hover:text-white transition-colors">My Wishlist</a>
          <a href="#" className="text-sm hover:text-white transition-colors">Track Your Order</a>
          <a href="#" className="text-sm hover:text-white transition-colors">Contact Us</a>
        </div>
      </div>
    </div>
  );
}
