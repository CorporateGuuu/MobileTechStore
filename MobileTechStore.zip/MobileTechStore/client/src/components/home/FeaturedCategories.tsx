export default function FeaturedCategories() {
  const categories = [
    {
      id: 1,
      name: "iPhone Batteries",
      image: "https://placehold.co/200x200/black/gold?text=iPhone+Batteries"
    },
    {
      id: 2,
      name: "iPhone Screens",
      image: "https://placehold.co/200x200/black/gold?text=iPhone+Screens"
    },
    {
      id: 3,
      name: "Back Housing",
      image: "https://placehold.co/200x200/black/gold?text=Back+Housing"
    },
    {
      id: 4,
      name: "Charging Ports",
      image: "https://placehold.co/200x200/black/gold?text=Charging+Ports"
    },
    {
      id: 5,
      name: "Repair Tools",
      image: "https://placehold.co/200x200/black/gold?text=Repair+Tools"
    },
    {
      id: 6,
      name: "Screen Protectors",
      image: "https://placehold.co/200x200/black/gold?text=Screen+Protectors"
    }
  ];
  
  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-black text-center mb-8">Featured Categories</h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories.map(category => (
            <a 
              key={category.id}
              href="#" 
              className="transition-transform duration-300 bg-white border border-gray-200 rounded-lg shadow-sm hover:shadow-md p-4 flex flex-col items-center hover:-translate-y-1 hover:border-gold"
            >
              <div className="w-24 h-24 mb-4">
                <img 
                  src={category.image} 
                  alt={category.name} 
                  className="w-full h-full object-contain"
                />
              </div>
              <h3 className="text-sm text-center font-medium text-black">{category.name}</h3>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
