import { useState, useEffect } from "react";

export default function HeroSlider() {
  const [activeSlide, setActiveSlide] = useState(0);
  const totalSlides = 4;
  
  // Auto-rotate slider
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % totalSlides);
    }, 5000);
    
    return () => clearInterval(interval);
  }, []);
  
  const handleDotClick = (index: number) => {
    setActiveSlide(index);
  };
  
  return (
    <section className="relative overflow-hidden" style={{ height: "400px" }}>
      <div className="absolute inset-0 bg-black">
        <div className="w-full h-full flex items-center justify-center">
          <div className="text-center px-4">
            <h1 className="text-4xl md:text-6xl font-bold text-gold mb-4">
              Midas Technical Solutions
            </h1>
            <p className="text-xl md:text-2xl text-white mb-6">
              Premium Phone & Tablet Repair Parts
            </p>
            <button className="bg-gold text-black px-8 py-3 rounded-md font-semibold hover:bg-opacity-90 transition-colors">
              Shop Now
            </button>
          </div>
        </div>
      </div>
      <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
        {[...Array(totalSlides)].map((_, index) => (
          <button
            key={index}
            onClick={() => handleDotClick(index)}
            className={`slider-dot w-3 h-3 ${
              activeSlide === index 
                ? "active bg-gold w-3 h-3 rounded-full cursor-pointer" 
                : "bg-white opacity-60 w-3 h-3 rounded-full cursor-pointer"
            }`}
            aria-label={`Go to slide ${index + 1}`}
          />
        ))}
      </div>
    </section>
  );
}
