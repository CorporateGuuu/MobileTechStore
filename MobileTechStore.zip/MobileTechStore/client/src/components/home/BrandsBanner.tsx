export default function BrandsBanner() {
  const brands = [
    { id: 1, name: "Apple", logo: "https://placehold.co/200x80/black/gold?text=Apple" },
    { id: 2, name: "Samsung", logo: "https://placehold.co/200x80/black/gold?text=Samsung" },
    { id: 3, name: "Google", logo: "https://placehold.co/200x80/black/gold?text=Google" },
    { id: 4, name: "LG", logo: "https://placehold.co/200x80/black/gold?text=LG" },
    { id: 5, name: "Motorola", logo: "https://placehold.co/200x80/black/gold?text=Motorola" },
    { id: 6, name: "OnePlus", logo: "https://placehold.co/200x80/black/gold?text=OnePlus" }
  ];

  return (
    <section className="py-10 bg-black">
      <div className="container mx-auto px-4">
        <h2 className="text-2xl font-bold text-gold text-center mb-8">Popular Brands</h2>
        <div className="flex flex-wrap justify-center items-center gap-8">
          {brands.map(brand => (
            <div 
              key={brand.id} 
              className="h-12 opacity-80 hover:opacity-100 transition-opacity"
            >
              <img 
                src={brand.logo} 
                alt={brand.name} 
                className="h-full" 
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
