import { FaShippingFast, FaUndo, FaShieldAlt, FaHeadset } from "react-icons/fa";

export default function InfoBanner() {
  const infoItems = [
    {
      id: 1,
      icon: <FaShippingFast className="text-xl" />,
      title: "Free Shipping",
      description: "On orders over $50"
    },
    {
      id: 2,
      icon: <FaUndo className="text-xl" />,
      title: "Easy Returns",
      description: "30-day return policy"
    },
    {
      id: 3,
      icon: <FaShieldAlt className="text-xl" />,
      title: "Secure Payment",
      description: "100% secure checkout"
    },
    {
      id: 4,
      icon: <FaHeadset className="text-xl" />,
      title: "24/7 Support",
      description: "Available until 10PM EST"
    }
  ];

  return (
    <section className="py-10 bg-white">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {infoItems.map(item => (
            <div key={item.id} className="flex items-center">
              <div className="w-12 h-12 flex-shrink-0 bg-gold rounded-full flex items-center justify-center text-black mr-4">
                {item.icon}
              </div>
              <div>
                <h3 className="font-semibold text-black">{item.title}</h3>
                <p className="text-sm text-gray-700">{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
