import { FaStar, FaStarHalfAlt, FaRegStar, FaShoppingCart } from "react-icons/fa";

// Midas Technical Solutions product data
const products = [
  {
    id: 1,
    name: "iPhone 15 Pro Max LCD Screen Replacement",
    price: 149.99,
    originalPrice: 199.99,
    image: "https://placehold.co/300x300/black/gold?text=iPhone+15+Screen",
    rating: 4.5,
    reviews: 42,
    badge: { type: "new", text: "New" }
  },
  {
    id: 2,
    name: "iPhone 14 Pro Max Battery Replacement",
    price: 39.99,
    originalPrice: 49.99,
    image: "https://placehold.co/300x300/black/gold?text=iPhone+Battery",
    rating: 5,
    reviews: 87,
    badge: { type: "bestseller", text: "Bestseller" }
  },
  {
    id: 3,
    name: "Samsung Galaxy S23 Ultra Screen Replacement",
    price: 129.99,
    originalPrice: 159.99,
    image: "https://placehold.co/300x300/black/gold?text=Galaxy+Screen",
    rating: 4,
    reviews: 23,
    badge: null
  },
  {
    id: 4,
    name: "iPad Pro 12.9\" 5th Gen Screen Replacement",
    price: 199.99,
    originalPrice: 249.99,
    image: "https://placehold.co/300x300/black/gold?text=iPad+Screen",
    rating: 4.5,
    reviews: 19,
    badge: null
  },
  {
    id: 5,
    name: "Professional Phone Repair Toolkit - 21 Pieces",
    price: 34.99,
    originalPrice: 49.99,
    image: "https://placehold.co/300x300/black/gold?text=Repair+Kit",
    rating: 5,
    reviews: 156,
    badge: { type: "sale", text: "Sale" }
  }
];

// Helper component for star ratings
const RatingStars = ({ rating }: { rating: number }) => {
  return (
    <div className="flex text-gold">
      {[...Array(5)].map((_, i) => (
        <span key={i}>
          {rating >= i + 1 ? (
            <FaStar className="text-xs" />
          ) : rating >= i + 0.5 ? (
            <FaStarHalfAlt className="text-xs" />
          ) : (
            <FaRegStar className="text-xs" />
          )}
        </span>
      ))}
    </div>
  );
};

export default function FeaturedProducts() {
  return (
    <section className="py-10 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-black">Featured Products</h2>
          <a href="#" className="text-gold hover:text-black font-medium">View All</a>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
          {products.map(product => (
            <div key={product.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow duration-300 overflow-hidden">
              <div className="relative p-4">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-40 object-contain mx-auto"
                />
                {product.badge && (
                  <span className={`absolute top-2 right-2 ${
                    product.badge.type === 'new' ? 'bg-gold text-black' : 
                    product.badge.type === 'bestseller' ? 'bg-black text-gold' : 
                    'bg-red-500 text-white'
                  } text-xs font-bold py-1 px-2 rounded`}>
                    {product.badge.text}
                  </span>
                )}
              </div>
              <div className="p-4 border-t border-gray-200">
                <h3 className="text-sm font-medium text-black mb-2 h-10 overflow-hidden">
                  {product.name}
                </h3>
                <div className="flex items-center mb-2">
                  <RatingStars rating={product.rating} />
                  <span className="text-xs text-gray-500 ml-1">({product.reviews})</span>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-lg font-bold text-gold">${product.price.toFixed(2)}</span>
                    <span className="text-xs text-gray-500 line-through ml-1">${product.originalPrice.toFixed(2)}</span>
                  </div>
                  <button className="w-8 h-8 rounded-full bg-black text-gold flex items-center justify-center hover:bg-gold hover:text-black transition-colors">
                    <FaShoppingCart className="text-xs" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
