export default function NewsletterSection() {
  return (
    <section className="py-10 bg-black text-gold">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center justify-between">
          <div className="mb-6 md:mb-0 md:w-1/2">
            <h2 className="text-2xl font-bold mb-2">Subscribe to Our Newsletter</h2>
            <p className="text-sm text-white opacity-80">
              Get the latest updates, deals and exclusive offers directly to your inbox.
            </p>
          </div>
          <div className="w-full md:w-1/2 max-w-md">
            <div className="flex">
              <input 
                type="email" 
                placeholder="Your email address" 
                className="flex-grow py-3 px-4 rounded-l-md text-black focus:outline-none"
              />
              <button className="bg-gold text-black font-semibold py-3 px-6 rounded-r-md hover:bg-opacity-90 transition-colors">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
