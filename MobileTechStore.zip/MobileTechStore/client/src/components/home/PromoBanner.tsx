export default function PromoBanner() {
  return (
    <section className="py-8">
      <div className="container mx-auto px-4">
        <div className="rounded-lg overflow-hidden bg-black p-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-gold mb-4">
              Premium Repair Parts & Tools
            </h2>
            <p className="text-white text-lg mb-6">
              Midas Technical Solutions offers high-quality repair parts and professional tools for all your device repair needs.
            </p>
            <button className="bg-gold text-black px-8 py-3 rounded-md font-semibold hover:bg-opacity-90 transition-colors">
              View Our Collection
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
